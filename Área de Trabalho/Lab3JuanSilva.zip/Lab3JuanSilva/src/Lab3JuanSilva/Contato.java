package Lab3JuanSilva;

/**
 *
 *
 * @author Juan Silva
 *
 */
public class Contato {
	/**
	 * Atributo responsável pelo nome do usúario em String.
	 */
	private String nome;
	/**
	 * Atributo responsável pelo sobrenome do usúario em String.
	 */
	private String sobrenome;
	/**
	 * Atributo responsável pela Lista de Strings por armazenar os telefones sendo
	 * eles, telefone1,telefone2,telefone3.
	 */
	private String[] telefones;
	/**
	 * Atributo responsável pela verificação de Telefone Prioritário sendo um
	 */
	private int verificacaoTelefonePrioritario;
	/**
	 * Atributo responsável pela verificação de Telefone Prioritário sendo um
	 */

	private int verificacaoContatoWhatsapp;

	public Contato(String nome, String sobrenome, String[] telefones, int verificacaoTelefonePrioritario,
			int verificacaoContatoWhatsapp) {

		this.nome = nome;
		this.sobrenome = sobrenome;
		this.telefones = telefones;
		this.verificacaoTelefonePrioritario = verificacaoTelefonePrioritario;
		this.verificacaoContatoWhatsapp = verificacaoContatoWhatsapp;
	}

	public String getNome() {
		return nome;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	/**
	 * Responsável por conferir o TELEFONE PRIORITÁRIO do usúario.
	 * 
	 * @return telefonePrioritario O telefone prioritário escolhido pelo usuário.
	 */
	public String getTelefonePrioritario() {
		if (verificacaoTelefonePrioritario == -1 || this.telefones[verificacaoTelefonePrioritario - 1].equals("")) {
			return "Não tem!";
		}
		return this.telefones[verificacaoTelefonePrioritario - 1];
	}

	/**
	 * Responsável por conferir o telefone utilizado como contato do WHATSAPP do
	 * usúario.
	 * 
	 * @return Retorna o contatoWhatsapp O contato do Whatsapp escolhido pelo
	 *         usuário.
	 */
	public String getContatoWhatsapp() {

		if (verificacaoContatoWhatsapp == -1 || this.telefones[verificacaoContatoWhatsapp - 1].equals("")) {
			return "Não tem!";
		}
		return this.telefones[verificacaoContatoWhatsapp - 1];
	}

	/**
	 * toString responsável por retornar um nome com sobrenome.
	 * 
	 * @return Retorna uma String com nome e sobrenome.
	 */
	@Override
	public String toString() {
		return this.nome + " " + this.sobrenome;
	}

	/**
	 * toStringTelefonePrioritario responsável por retornar o telefone prioritário
	 * do contato determinado.
	 * 
	 * @return Retorna uma String com nome, sobrenome e o telefone prioritário.
	 */
	public String toStringTelefonePrioritario() {
		return this.nome + " " + this.sobrenome + " - " + getTelefonePrioritario();
	}

	/**
	 * responsável por retornar o contato do whatsapp escolhido pelo usúario.
	 * 
	 * @return Retorna uma String com nome, sobrenome e o Contato do Whatsapp.
	 */
	public String toStringContatoWhatsapp() {
		return this.nome + " " + this.sobrenome + " - " + getContatoWhatsapp();
	}

	/**
	 * Responsável por exibir telefone prioritário na formatação da "opção exibir
	 * contato".
	 * 
	 * @return Retorna uma String com nome, sobrenome e telefone prioritário
	 *         formatado para opção exibir
	 */
	public String toStringExibeTelefonePrioritario() {
		return this.nome + " " + this.sobrenome + "\n" + this.getTelefonePrioritario();
	}

	/**
	 * Responsável por exibir contato Whatsapp na formatação da "opção exibir
	 * contato".
	 * 
	 * @return Retorna uma String com nome, sobrenome e contato Whatsapp formatado
	 *         para opção exibir
	 */
	public String toStringExibeContatoWhatsapp() {
		return this.getContatoWhatsapp();
	}

	/**
	 * hashCode referente a identificação classe Contato.
	 * 
	 * @return result retorna uma representação única para o contato
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((sobrenome == null) ? 0 : sobrenome.hashCode());
		return result;
	}

	/**
	 * equals referente a comparação contatos na classe Contato.
	 * 
	 * @return true para classe iguais.
	 * @return false para classes diferentes.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contato other = (Contato) obj;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (sobrenome == null) {
			if (other.sobrenome != null)
				return false;
		} else if (!sobrenome.equals(other.sobrenome))
			return false;
		return true;
	}

}