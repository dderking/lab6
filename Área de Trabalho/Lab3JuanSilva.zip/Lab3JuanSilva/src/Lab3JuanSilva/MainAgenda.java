package Lab3JuanSilva;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 * Interface com menus texto para manipular uma agenda de contatos.
 * 
 * @author Juan Silva
 *
 */
public class MainAgenda {

	public static void main(String[] args) {
		/**
		 * Atributo responsável pela criação da nova agenda.
		 */
		Agenda agenda = new Agenda();

		System.out.println("Carregando agenda inicial");
		try {

			/*
			 * Essa é a maneira de lidar com possíveis erros por falta do arquivo.
			 */
			carregaAgenda("agenda_inicial.csv", agenda);
		} catch (FileNotFoundException e) {
			System.err.println("Arquivo nao encontrado: " + e.getMessage());
		} catch (IOException e) {
			System.err.println("Erro lendo arquivo: " + e.getMessage());
		}

		Scanner scanner = new Scanner(System.in);
		String opcao = "";
		while (true) {
			opcao = menu(scanner);
			comando(opcao, agenda, scanner);
		}

	}

	/**
	 * Exibe o menu e captura a escolha do/a usuário/a.
	 * 
	 * @param sc Para captura da opção do usuário.
	 * @return O comando escolhido.
	 */
	private static String menu(Scanner sc) {
		System.out.print("\n----------------------\nMENU\n" + "(C)adastrar Contato\n" + "(L)istar Contatos\n"
				+ "(E)xibir Contato\n" + "(T)elefone Preferido\n" + "(Z)aps\n" + "(S)air\n" + "----------------------\n"
				+ "Opcao> ");
		return sc.next().toUpperCase();
	}

	/**
	 * Interpreta a opção escolhida por quem está usando o sistema.
	 * 
	 * @param opcao   Opção digitada.
	 * @param agenda  A agenda que estamos manipulando.
	 * @param scanner Objeto scanner para o caso do comando precisar de mais input.
	 */
	private static void comando(String opcao, Agenda agenda, Scanner scanner) {
		switch (opcao) {
		case "C":
			cadastraContato(agenda, scanner);
			break;
		case "L":
			listaContatos(agenda);
			break;
		case "E":
			exibeContato(agenda, scanner);
			break;
		case "T":
			exibeTelefonePrioritario(agenda);
			break;
		case "Z":
			exibeContatoWhatsapp(agenda);
			break;
		case "S":
			sai();
			break;
		default:
			System.out.println("Opção INVÁLIDA!");
		}
	}

	/**
	 * Cadastra um contato na agenda.
	 * 
	 * @param agenda  A agenda.
	 * @param scanner Scanner para pedir informações do contato.
	 */
	private static boolean cadastraContato(Agenda agenda, Scanner scanner) {
		String[] telefones = new String[3];

		System.out.print("Posicao na agenda: ");
		int posicao = scanner.nextInt();
		if (posicao < 1 || posicao > 100) {
			System.out.print("POSIÇÃO INVÁLIDA");
			return false;
		}
		scanner.nextLine();
		System.out.print("Nome: ");
		String nome = scanner.nextLine();
		System.out.print("Sobrenome: ");
		String sobrenome = scanner.nextLine();
		for (int i = 1; i <= telefones.length; i++) {
			System.out.print("Telefone" + i + ": ");
			String telefone = scanner.nextLine();
			telefones[i - 1] = telefone;

		}
		System.out.print("Telefone prioritario: ");
		String recebeTelefonePrioritario = scanner.nextLine().strip();
		int telefonePrioritario;
		if (recebeTelefonePrioritario == "") {
			telefonePrioritario = -1;
		} else {
			telefonePrioritario = Integer.parseInt(recebeTelefonePrioritario);
		}
		System.out.print("Contato Whatsapp: ");
		String recebeContatoWhatsapp = scanner.nextLine().strip();
		int contatoWhatsapp;
		if (recebeContatoWhatsapp == "") {
			contatoWhatsapp = -1;
		} else {
			contatoWhatsapp = Integer.parseInt(recebeContatoWhatsapp);
		}
		System.out.println("CADASTRO REALIZADO");
		agenda.cadastraContato(posicao, nome, sobrenome, telefones, telefonePrioritario, contatoWhatsapp);
		return true;

	}

	/**
	 * Imprime lista de contatos da agenda.
	 * 
	 * @param agenda A agenda sendo manipulada.
	 */
	private static void listaContatos(Agenda agenda) {
		System.out.println("\nLista de contatos: ");
		Contato[] contatos = agenda.getContatos();
		for (int i = 0; i < contatos.length; i++) {
			if (contatos[i] != null) {
				System.out.println(formataContato((i + 1), contatos[i]));
			}
		}
	}

	/**
	 * Imprime os detalhes de um dos contatos da agenda.
	 * 
	 * @param agenda  A agenda.
	 * @param scanner Scanner para capturar qual contato.
	 */
	private static boolean exibeContato(Agenda agenda, Scanner scanner) {
		System.out.print("\nQual contato> ");
		int posicao = scanner.nextInt();
		if (posicao < 1 || posicao > 100) {
			System.out.println("Posição errada");
			return false;
		}
		Contato contato = agenda.getContato(posicao);
		if (contato == null) {
			System.out.println("Contato inexistente.");
			return false;
		}
		System.out.println(agenda.getContato(posicao).toStringExibeTelefonePrioritario() + " (prioritário)");
		System.out.println(agenda.getContato(posicao).toStringExibeContatoWhatsapp() + " (zap)");
		return true;
	}

	/**
	 * Responsável por exibir o numero de telefone prioritário do usuario.
	 * 
	 * @param agenda agenda onde está o telefone prioritário.
	 */
	private static void exibeTelefonePrioritario(Agenda agenda) {
		System.out.print("\n" + agenda.getTelefonePrioritario());
	}

	/**
	 * Responsável por exibir o numero de Contato de Whatsapp do usuario.
	 * 
	 * @param agenda
	 */
	private static void exibeContatoWhatsapp(Agenda agenda) {
		System.out.println("\n" + agenda.getContatoWhatsapp());
	}

	/**
	 * Formata um contato para impressão na interface.
	 * 
	 * @param posicao A posição do contato (que é exibida)/
	 * @param contato O contato a ser impresso.
	 * @return A String formatada.
	 */
	private static String formataContato(int posicao, Contato contato) {
		return posicao + ": " + contato;
	}

	/**
	 * Sai da aplicação e manda uma mensagem de confirmação de saída para o usuário.
	 */
	private static void sai() {
		System.out.println("\nVlw flw o/");
		System.exit(0);
	}

	/**
	 * Lê uma agenda de um arquivo csv.
	 * 
	 * @param arquivoContatos O caminho para o arquivo.
	 * @param agenda          A agenda que deve ser populada com os dados.
	 * @throws IOException Caso o arquivo não exista ou não possa ser lido.
	 */
	private static void carregaAgenda(String arquivoContatos, Agenda agenda) throws FileNotFoundException, IOException {
		LeitorDeAgenda leitor = new LeitorDeAgenda();

		int carregados = leitor.carregaContatos(arquivoContatos, agenda);
		System.out.println("Carregamos " + (carregados - 1) + " registros.");
	}
}