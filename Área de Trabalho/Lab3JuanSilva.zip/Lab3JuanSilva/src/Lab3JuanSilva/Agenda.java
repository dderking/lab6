package Lab3JuanSilva;

import java.util.Arrays;

/**
 * Uma agenda que mantém uma lista de contatos com posições. Podem existir 100
 * contatos.
 * 
 * @author Juan Silva
 *
 */
public class Agenda {
	/**
	 * @
	 */
	private Contato[] contatos;
	/**
	 * Constante responsável pela declaração do tamanho da agenda
	 */
	private static final int TAMANHO_AGENDA = 100;

	/**
	 * Contrutor responsável pela criação de uma agenda.
	 */
	public Agenda() {
		this.contatos = new Contato[TAMANHO_AGENDA];
	}

	/**
	 * Acessa a lista de contatoS mantida.
	 * 
	 * @return O array de contatos.
	 */
	public Contato[] getContatos() {
		return this.contatos.clone();
	}

	/**
	 * Acessa os dados de UM contato especifico.
	 * 
	 * @param posicao Posição do contato na agenda.
	 * @return Dados do contato. Null se não existe contato na posição.
	 */
	public Contato getContato(int posicao) {
		if (this.contatos[posicao - 1] == null) {
			throw new NullPointerException();
		}
		return contatos[posicao - 1];
	}

	/**
	 * Responsável por retornar o telefone prioritário dos contatos.
	 * 
	 * @return Retorna uma String com o telefones prioritário dos contatos.
	 */
	public String getTelefonePrioritario() {
		String telefonePrioritario = "";
		for (int i = 0; i < contatos.length; i++) {
			if (contatos[i] != null) {
				telefonePrioritario += contatos[i].toStringTelefonePrioritario() + "\n";
			}
		}
		return telefonePrioritario;
	}

	/**
	 * Responsável por retornar uma String com o contato de Whatsapp dos contatos.
	 * 
	 * @return Retorna uma String referente a Contato Whatsapp do contatos.
	 */
	public String getContatoWhatsapp() {
		String contatoWhatsapp = "";
		for (int i = 0; i < contatos.length; i++) {
			if (contatos[i] != null) {
				contatoWhatsapp += contatos[i].toStringContatoWhatsapp() + "\n";
			}
		}
		return contatoWhatsapp;
	}

	/**
	 * CADASTRA um contato em uma posição. Um cadastro em uma posição que já existe
	 * sobrescreve o anterior.
	 * 
	 * @param posicao             Posição do contato.
	 * @param nome                Nome do contato.
	 * @param sobrenome           Sobrenome do contato
	 * @param contatoWhatsapp     Whatsapp do contato
	 * @param telefonePrioritario Telefone Prioritário do contato.
	 * @param telefones           Telefones do contato onde pode ser até 3 contatos.
	 */
	public void cadastraContato(int posicao, String nome, String sobrenome, String[] telefones, int telefonePrioritario,
			int contatoWhatsapp) {
		Contato contato = new Contato(nome, sobrenome, telefones, telefonePrioritario, contatoWhatsapp);
		this.contatos[posicao - 1] = contato;
	}

	/**
	 * hashCode referente a identificação classe Agenda.
	 * 
	 * @return result retorna uma representação única para o contato
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(contatos);
		return result;
	}

	/**
	 * equals referente a comparação contatos na classe AgendaFF.
	 * 
	 * @return true para classe iguais.
	 * @return false para classes diferentes.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Agenda other = (Agenda) obj;
		if (!Arrays.equals(contatos, other.contatos))
			return false;
		return true;
	}

}