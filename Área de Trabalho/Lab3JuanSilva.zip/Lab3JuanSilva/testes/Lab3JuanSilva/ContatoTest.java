package Lab3JuanSilva;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContatoTest {
	/**
	 * Atributo referente a um contato do tipo contatos
	 */
	private Contato contatoBasico;
	/**
	 * Atributo referente a um contato do tipo contatos
	 */
	private Contato contatoBasico2;
	/**
	 * Atributo referente a um contato do tipo contatos
	 */
	private Contato contatoBasico3;

	@BeforeEach
	public void criaContato() {
		contatoBasico = new Contato("Matheus", "Gaudencio", new String[] { "2101-0000", "99696-7272", "99696-9591" }, 2,
				2);
		contatoBasico2 = new Contato("Juan", "Silva", new String[] { "(83)99696-7272", "(11)4002-8922", "99696-9591" },
				-1, 2);
		contatoBasico3 = new Contato("Juan", "Silva", new String[] { "(83)99696-7272", "(11)4002-8922", "99696-9591" },
				2, -1);
	}

	@Test
	public void testEqualsSobrenomeDiferente() {
		assertFalse(contatoBasico.equals(new Contato("Matheus", "Rego", new String[] { "2101-0000", "99696-7272", "99696-9591" }, 2,
				2)));
	}

	@Test
	public void testEqualsMesmoContato() {
		assertTrue(contatoBasico.equals(contatoBasico));
	}

	@Test
	public void testEqualsTiposDiferentes() {
		assertFalse(contatoBasico.equals(new Agenda()));
	}

	/**
	 * testa se o contato é null.
	 */
	@Test
	public void testEqualsContatoNull() {
		assertFalse(contatoBasico.equals(null));
	}

	/**
	 * testa e compara se os HashCode se parecem.
	 */
	@Test
	public void testHashCode() {
		assertEquals(contatoBasico2.hashCode(), contatoBasico3.hashCode());
	}

	/**
	 * Testa se os nomes são iguais.
	 */
	@Test
	public void testEqualsContatosIguais() {
		assertTrue(contatoBasico2.equals(contatoBasico3));
	}

	/**
	 * Testa se os nomes são iguais.
	 */
	@Test
	public void testEqualsContatosDiferentes() {
		assertFalse(contatoBasico.equals(contatoBasico2));
	}

	/**
	 * Testa a saída do nome.
	 */
	@Test
	public void testGetNome() {
		assertEquals("Matheus", contatoBasico.getNome());
	}

	/**
	 * Testa a saída do sobrenome.
	 */
	@Test
	public void testGetSobrenome() {
		assertEquals("Gaudencio", contatoBasico.getSobrenome());
	}

	/**
	 * Testa a saída do sem telefone prioritário.
	 */
	@Test
	public void testGetSemTelefoneProritario() {
		assertEquals("Não tem!", contatoBasico2.getTelefonePrioritario());
	}

	/**
	 * Testa a saída do com telefone prioritário.
	 */
	@Test
	public void testGetTelefonePrioritario() {
		assertEquals("99696-7272", contatoBasico.getTelefonePrioritario());
	}

	/**
	 * Testa a saída do sem o contato Whatsapp.
	 */
	@Test
	public void testGetSemContatoWhatsapp() {
		assertEquals("Não tem!", contatoBasico3.getContatoWhatsapp());
	}

	/**
	 * Testa a saída do com o contato Whatsapp.
	 */
	@Test
	public void testGetContatoWhatsapp() {
		assertEquals("99696-7272", contatoBasico.getContatoWhatsapp());
	}

	/**
	 * Testa a saída com nome e sobrenome do contato.
	 */
	@Test
	public void testToString() {
		assertEquals("Matheus Gaudencio", contatoBasico.toString());
	}

	/**
	 * Testa a saída de telefone prioritário.
	 */
	@Test
	public void testToStringTelefonePrioritario() {
		assertEquals("Matheus Gaudencio - 99696-7272", contatoBasico.toStringTelefonePrioritario());
	}

	/**
	 * Testa a saída do contato de Whatsapp.
	 */
	@Test
	public void testToStringContatoWhatsapp() {
		assertEquals("Matheus Gaudencio - 99696-7272", contatoBasico.toStringContatoWhatsapp());
	}

	/**
	 * Testa a saída da exibição do telefone prioritário.
	 */
	@Test
	public void testToStringExibeTelefonePrioritario() {
		assertEquals("Matheus Gaudencio\n99696-7272", contatoBasico.toStringExibeTelefonePrioritario());
	}

	/**
	 * Testa a saída da Exibição dos contato de Whatsapp.
	 */
	@Test
	public void testToStringExibeContatoWhatsapp() {
		assertEquals("99696-7272", contatoBasico.toStringExibeContatoWhatsapp());
	}
}
