package Lab3JuanSilva;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AgendaTest {

	private Agenda agenda;
	private Agenda agenda2;
	private Agenda agenda3;

	@BeforeEach
	public void criaAgenda() {
		this.agenda = new Agenda();
		this.agenda2 = new Agenda();
		this.agenda3 = new Agenda();
		agenda.cadastraContato(1, "Juan", "Salvador",
				new String[] { "(83)99696-7272", "(11)4002-8922", "(83) 996429591" }, 1, 1);
		agenda.cadastraContato(3, "Matheus", "Gaudencio",
				new String[] { "(83)66666-4444", "(11)31312-1111", "(83) 12313133" }, -1, 1);
		agenda.cadastraContato(4, "Ramalho", "Guedes",
				new String[] { "(83)13131-8181", "(11)15156-2222", "(83) 19291414" }, 1, -1);
		agenda2.cadastraContato(1, "Juan", "Salvador",
				new String[] { "(83)99696-7272", "(11)4002-8922", "(83) 996429591" }, 1, 1);
		agenda3.cadastraContato(1, "Juan", "Salvador",
				new String[] { "(83)99696-7272", "(11)4002-8922", "(83) 996429591" }, 1, 1);

	}

	@Test
	public void testGetContatos() {
		Contato[] contatosTeste = new Contato[100];
		contatosTeste[0] = new Contato("Juan", "Salvador",
				new String[] { "(83)99696-7272", "(11)4002-8922", "(83)996429591" }, 1, 1);
		Assertions.assertArrayEquals(contatosTeste, agenda3.getContatos());
	}

	@Test
	public void testGetContato() {
		assertEquals(new Contato("Juan", "Salvador",
				new String[] { "(83)99696-7272", "(11)4002-8922", "(83)996429591" }, 1, 1), agenda.getContato(1));

	}

	@Test
	public void testGetContatoNull() {
		Assertions.assertThrows(NullPointerException.class, () -> {
			agenda.getContato(50);
		});
	}

	@Test
	public void testEqualsAgendaNull() {
		assertFalse(agenda.equals(null));
	}

	@Test
	public void testHashCodeDiferente() {
		assertNotEquals(agenda.hashCode(), agenda2.hashCode());
	}

	@Test
	public void testHashCodeIgual() {
		assertEquals(agenda2.hashCode(), agenda3.hashCode());
	}

	@Test
	public void testEqualsMesmaAgenda() {
		assertTrue(agenda.equals(agenda));
	}

	@Test
	public void testEqualsTiposDiferentes() {
		assertFalse(agenda.equals(new Contato("Juan", "Salvador",
				new String[] { "(83)99696-7272", "(11)4002-8922", "(83)996429591" }, 1, 1)));
	}

	@Test
	public void testEqualsAgendasIguais() {
		assertTrue(agenda2.equals(agenda3));
	}

	@Test
	public void testEqualsAgendaDiferente() {
		assertFalse(agenda.equals(agenda2));
	}

	@Test
	public void testGetTelefonePrioritario() {
		assertEquals(
				"Juan Salvador - (83)99696-7272\nMatheus Gaudencio - Não tem!\nRamalho Guedes - (83)13131-8181".trim(),
				agenda.getTelefonePrioritario().trim());
	}

	@Test
	public void testGetContatoWhatsapp() {
		assertEquals(
				"Juan Salvador - (83)99696-7272\nMatheus Gaudencio - (83)66666-4444\nRamalho Guedes - Não tem!".trim(),
				agenda.getContatoWhatsapp().trim());
	}
}
